import SwiftUI

struct MentalHealthView: View {
    var body: some View {
        NavigationView { // Use NavigationView for a title
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("University Mental Health Resources")
                        .font(.title)
                        .bold()
                        .padding(.bottom)

                    Text("Important: This chatbot is not a substitute for professional mental health support. If you are in crisis or need support, please reach out to the resources below.")
                        .font(.callout)
                        .foregroundColor(.red)
                        .padding(.bottom)

                    ResourceSection(
                        title: "College Counseler ",
                        details: [
                            "Phone: 011 111 1111",
                            "Email: sara@ksu.edu.sa",
                            "Location: Building 6 , Room G62",
                            "Hours: Sun-Thur, 9 AM - 5 PM",
                          
                        ]
                    )


                    ResourceSection(
                        title: "Ambulance",
                        details: ["Phone: 988"]
                    )

                  

                    Spacer() // Push content to top
                }
                .padding()
            }
            .navigationTitle("Mental Health Support")
        }
    }
}

// Helper view for resource sections
struct ResourceSection: View {
    let title: String
    let details: [String]

    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.headline)
            ForEach(details, id: \.self) { detail in
                Text(detail)
                    .font(.body)
            }
        }
    }
}
