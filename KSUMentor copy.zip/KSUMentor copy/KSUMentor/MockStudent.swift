import Foundation

struct MockStudent: Identifiable {
    let id = UUID()
    let name: String = "Alex Student"
    let studentID: String = "S123456"
    var major: String = "Computer Science"
    var yearLevel: Int = 2 // 1=Freshman, 2=Sophomore, etc.
    var gpa: Double = 3.5
    var enrolledCourses: [String] = ["CS 201", "MATH 203", "PHYS 102", "ENGL 110"]
    var interests: [String] = ["Programming", "AI", "Hiking"]
    var volunteerHours: Int = 15
}
