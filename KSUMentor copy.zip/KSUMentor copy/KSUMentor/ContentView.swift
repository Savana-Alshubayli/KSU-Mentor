// In KSUMentor/ContentView.swift

import SwiftUI

struct ContentView: View {
    @State private var columnVisibility: NavigationSplitViewVisibility = .automatic
    @State private var searchText = ""
    @State private var selectedChat: ChatType? = .general
    @State private var showCalendar = false

    var body: some View {
        GeometryReader { geometry in
            NavigationSplitView(columnVisibility: $columnVisibility) { // Sidebar
                SidebarView(selectedChat: $selectedChat, searchText: $searchText, showCalendar: $showCalendar)
                    // --- ADJUSTED WIDTHS ---
                    // Make the sidebar ideally wider (e.g., 70% of the screen)
                    .navigationSplitViewColumnWidth(
                        min: geometry.size.width * 0.4,  // Minimum 40%
                        ideal: geometry.size.width * 0.7, // Ideal 70% (Increased from 0.5)
                        max: geometry.size.width * 0.9  // Maximum 90%
                    )

            } detail: { // Detail view (Chat)
                // The detail view will take the remaining space
                ChatContainerView(selectedChat: selectedChat)
                    .background(Color(.systemGray6).ignoresSafeArea()) // Keep background
            }
            .preferredColorScheme(.dark) // Keep dark mode
        } // End GeometryReader
    }
}

// Keep your existing ChatType enum
enum ChatType: String, CaseIterable, Identifiable, Hashable {
    case general = "General"
    case community = "Community"
    case gradGate = "GradGate"
    case mentalHealth = "Mental Health"

    var id: String { self.rawValue }
}
