import SwiftUI

struct CalendarViewWithEvents: View {
    // Sample exam and project due dates (replace with your actual data)
    let events: [Date: [String]] = [
        Calendar.current.date(byAdding: .day, value: 5, to: Date())!: ["Midterm Exam - Math 101"],
        Calendar.current.date(byAdding: .day, value: 12, to: Date())!: ["Project Proposal Due"],
        Calendar.current.date(byAdding: .day, value: 20, to: Date())!: ["Final Exam - CS 201"]
    ]

    var body: some View {
        Text("Calendar View")
        // Implement your calendar UI here
        // You can iterate through the 'events' dictionary to display events on specific dates

        List {
            ForEach(events.sorted(by: { $0.key < $1.key }), id: \.key) { date, descriptions in
                Section(header: Text(date, style: .date)) {
                    ForEach(descriptions, id: \.self) { description in
                        Text(description)
                    }
                }
            }
        }
    }
}
