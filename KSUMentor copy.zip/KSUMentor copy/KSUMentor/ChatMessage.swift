import Foundation

struct ChatMessage: Identifiable {
    let id = UUID()
    let text: String
    let isUser: Bool // True if the user sent it, false if it's the bot
    let timestamp: Date = Date()
}
