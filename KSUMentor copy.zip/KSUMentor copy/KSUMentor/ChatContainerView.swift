import SwiftUI

struct ChatContainerView: View {
    let selectedChat: ChatType?

    var body: some View {
        if let selectedChat = selectedChat {
            switch selectedChat {
            case .general:
                GeneralChatView()
            case .community:
                CommunityChatView()
            case .gradGate:
                GradGateChatView()
            case .mentalHealth:
                MentalHealthView()
            }
        } else {
            Text("Select a chat to start.") // Default view when no chat is selected
        }
    }
}
