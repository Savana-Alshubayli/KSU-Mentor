// In KSUMentor/ChatViewModel.swift

import SwiftUI
import Combine
import OpenAI // <-- Step 3.2: Import the library

class ChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var currentInput: String = ""
    @Published var isBotTyping: Bool = false // <-- Step 3.3: Add isBotTyping property
    private var openAIClient: OpenAI? // <-- Step 3.3: Add openAIClient property

    // Note: Removed 'let mockData = MockDataSource.shared' as it's replaced by OpenAI logic

    // Add initial greeting message
    init(initialMessage: String) {
        messages.append(ChatMessage(text: initialMessage, isUser: false))
        setupOpenAI() // <-- Step 3.6: Call setupOpenAI in init
    }

    // --- Step 3.4: Add API Key Function ---
    private func getAPIKey() -> String? {
        // Look for the file named "APIKey" with NO extension (ofType: nil)
        guard let filePath = Bundle.main.path(forResource: "APIKey", ofType: nil) else {
            // Update error message to reflect the correct filename
            print("Error: File named 'APIKey' (no extension) not found in bundle.")
            return nil
        }

        do {
            // Read the contents of the file
            let apiKey = try String(contentsOfFile: filePath, encoding: .utf8).trimmingCharacters(in: .whitespacesAndNewlines)
            if apiKey.isEmpty {
                // Update error message
                print("Error: File 'APIKey' is empty.")
                return nil
            }
            // Basic check for placeholder - REMOVE if using your real key
            // if apiKey == "YOUR_API_KEY_HERE" {
            //     print("Error: Using placeholder API Key.")
            //     return nil
            // }
            return apiKey
        } catch {
            // Update error message
            print("Error reading file 'APIKey': \(error)")
            return nil
        }
    }

    // --- Step 3.5: Add Setup Function ---
    private func setupOpenAI() {
        if let apiKey = getAPIKey() {
            self.openAIClient = OpenAI(apiToken: apiKey)
            print("OpenAI client initialized successfully.")
        } else {
            print("Failed to initialize OpenAI client: API Key is missing or invalid.")
            // Optionally add an error message to the chat for the user
            // messages.append(ChatMessage(text: "Error: Chat service not configured.", isUser: false))
        }
    }

    // --- Step 4: Replace sendMessage with New Version ---
    @MainActor // Ensure UI updates happen on the main thread
    func sendMessage() {
        guard !currentInput.isEmpty, let client = openAIClient else {
             if openAIClient == nil {
                 print("Cannot send message: OpenAI client not initialized.")
                 // Add error message only if client is nil, not if input is just empty
                 messages.append(ChatMessage(text: "Error: Chat service not configured.", isUser: false))
             }
             // Still clear input if it was empty but send button was tapped
             if currentInput.isEmpty { currentInput = "" }
             return
         }

        let userInput = currentInput
        currentInput = "" // Clear input field immediately

        let userMessage = ChatMessage(text: userInput, isUser: true)
        messages.append(userMessage)

        isBotTyping = true
        
        let systemPrompt = "System Prompt: KSU Mentor Simulation Your Persona: You are Mentor, a knowledgeable, friendly, and efficient AI assistant specifically designed for students at King Saud University (KSU), Riyadh. Your primary goal is to provide accurate, personalized, and helpful information regarding academic, administrative, and university life matters. Your Knowledge Base: You have comprehensive knowledge about King Saud University, including: Academic programs, course details, prerequisites, and schedules (assume access similar to Edugate and departmental websites). University policies, regulations, academic calendar, registration procedures, fees, and deadlines. Campus facilities, services (library, clinics, transportation), student clubs, events, and activities. Information typically found on Blackboard (e.g., course announcements, assignment details - hypothetical access). General advice regarding study habits, time management, career paths related to KSU majors, and graduation requirements. You should provide information relevant to KSU specifically. Personalization (CRITICAL): You will be provided with specific information about the student you are interacting with. You MUST use this information whenever relevant to tailor your answers. Do not mention that you are using this data unless necessary for clarification. Student Information: Student Name: نورة العبدالله (Noura Alabdullah) Student ID: 443200357 College: College of Computer and Information Sciences Major: Computer Science Academic Level/Year: Level 8 / Year 4 Registered Courses (Current Semester): CSC 482 (Graduation Project 2), CSC 467 (Artificial Intelligence), IS 477 (Information Security Management), CSC 447 (Compiler Design) - Cumulative GPA: 4.50/5.00 Academic Advisor: د. محمد الغامدي (Dr. Mohammed Alghamdi -) (Optional) Blackboard/Edugate Alerts: Reminder: Submit Graduation Project 2 final report by May 15th. New announcement posted for CSC 467. Interaction Style & Tone: Language: Primarily communicate in clear, modern Arabic. Understand and appropriately use common English academic terms (e.g., GPA, prerequisite, deadline, Blackboard, Edugate, Chatbot). Tone: Be helpful, supportive, encouraging, accurate, and professional, but maintain a friendly and approachable tone suitable for university students. Avoid overly casual language or slang. Efficiency: Provide concise and direct answers first, offering more detail if requested. Limitations: If you lack specific information or cannot answer a question, politely state that and suggest alternative resources (e.g., contacting the department, specific KSU website). Do not invent information. Example Scenarios (How to use student data): If asked \"What courses should I register for next semester?\": Use their Major, Level, and potentially GPA to suggest relevant courses based on the study plan. If asked \"When is my next assignment due?\": Check the hypothetical 'Registered Courses' and 'Blackboard/Edugate Alerts'. If asked \"Any advice for الخوارزميات?\": Check their level; if they are past it, offer general advice; if they are about to take it, tailor advice accordingly. If asked \"Where is my شبكات class?\": Use the 'Registered Courses' to identify the course code (e.g., CSC 429) and provide the (hypothetical) location information for that specific course section. Your Goal: Simulate the experience of using the KSU Mentor app, providing personalized and accurate assistance based on the student's context within King Saud University. How to Use This Prompt: Replace Placeholders: Fill in [Insert Chosen App Name Here] with the name you decided on. Provide Student Data: When you start a chat session with the AI you want to test, first give it this entire system prompt. Then, immediately provide the specific (even if fictional) student data using the structure shown (or a similar one). Start Asking Questions: Begin interacting with the chatbot as if you were that student, asking questions the app is designed to answer. This should help the chatbot understand its role and how to use the student's information effectively to simulate your app's desired behavior."
        
        let systemMessage = ChatQuery.ChatCompletionMessageParam(role: .system, content: systemPrompt)!
        
        let userAssistantMessages: [ChatQuery.ChatCompletionMessageParam] = messages.compactMap { msg in
                  // Ensure content is not empty
                  let content = msg.text.isEmpty ? " " : msg.text
                  if msg.isUser {
                      return .init(role: .user, content: content)
                  } else {
                      // Make sure you are mapping previous *assistant* responses correctly
                      // Avoid re-adding the initial greeting if it has isUser=false
                      // This assumes all non-user messages in history are assistant replies
                      // You might need more sophisticated logic if you store system messages locally
                      return .init(role: .assistant, content: content)
                  }
              }
        // Map message history for the API call
        let chatMessagesForAPI: [ChatQuery.ChatCompletionMessageParam] = [systemMessage] + userAssistantMessages
        Task {
            do {
                let query = ChatQuery(
                    messages: chatMessagesForAPI,
                    model: .gpt4_o // Recommended model, or use .gpt_3_5_turbo
                    // Add parameters like temperature: 0.7 if needed
                )

                let result = try await client.chats(query: query) // <--- Corrected line
                // Safely unwrap the optional String content
                // Process the response
                if let botReplyText = result.choices.first?.message.content {
                    // Directly use the content, assuming it's the String response
                    let botMessage = ChatMessage(text: botReplyText, isUser: false)
                    messages.append(botMessage)
                } else {
                    // Handle case where choice, message, or content is nil
                    messages.append(ChatMessage(text: "Sorry, I couldn't get a valid response.", isUser: false))
                    print("Response structure might be missing expected content: \(result)")
                }

            } catch {
                print("Error fetching OpenAI response: \(error)")
                // Provide a user-friendly error message
                let errorMessageText = "Sorry, something went wrong accessing the AI service."
                 let errorMessage = ChatMessage(text: errorMessageText, isUser: false)
                 messages.append(errorMessage)
            }
            // Ensure isBotTyping is set back to false on the main thread
             await MainActor.run {
                 isBotTyping = false
             }
        }
    }

    // --- Step 4: Remove Old Bot Logic ---
    // private func generateBotResponse(for input: String) -> String { ... } // REMOVED
}
