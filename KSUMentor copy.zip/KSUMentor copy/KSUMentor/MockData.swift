import Foundation
import MapKit // Import if using MapKit for locations

struct MockEvent: Identifiable {
    let id = UUID()
    let name: String
    let date: String
    let description: String
}

struct MockClub: Identifiable {
    let id = UUID()
    let name: String
    let description: String
    let meetingInfo: String
}

struct MockFaculty: Identifiable {
    let id = UUID()
    let name: String
    let department: String
    let email: String
    let office: String
}

struct MockLocation {
    let name: String
    let building: String
    let room: String
    // Optional: Add coordinates for MapKit
    // let coordinate: CLLocationCoordinate2D
}

// Centralized Mock Data Store
struct MockDataSource {
    static let shared = MockDataSource() // Singleton for easy access

    let currentUser = MockStudent()

    let events: [MockEvent] = [
        MockEvent(name: "AI Workshop", date: "May 5th, 2 PM", description: "Intro to AI concepts."),
        MockEvent(name: "Career Fair", date: "May 10th, 10 AM - 4 PM", description: "Meet potential employers.")
    ]

    let clubs: [MockClub] = [
        MockClub(name: "Debate Club", description: "Discuss current events.", meetingInfo: "Tuesdays 6 PM, Room 101"),
        MockClub(name: "Coding Club", description: "Work on projects.", meetingInfo: "Thursdays 7 PM, CompSci Lab")
    ]

    let faculty: [MockFaculty] = [
        MockFaculty(name: "Dr. Evelyn Reed", department: "Physics", email: "ereed@university.edu", office: "Science Bldg 304"),
        MockFaculty(name: "Prof. Ben Carter", department: "Computer Science", email: "bcarter@university.edu", office: "Eng Bldg 210")
    ]

    let locations: [MockLocation] = [
         MockLocation(name: "CS 201 Lecture", building: "Engineering Building", room: "Room 205"),
         MockLocation(name: "Physics Lab", building: "Science Building", room: "Lab 1A"),
         MockLocation(name: "Library", building: "Main Library", room: "Main Floor")
    ]

    let examSchedule: [String: String] = [
        "CS 201": "May 15th, 9 AM",
        "MATH 203": "May 17th, 1 PM"
    ]

    // Add more mock data (internships, research, PDFs, etc.) as needed
}
