import SwiftUI

struct CommunityChatView: View {
    // Use @StateObject for the ViewModel
    @StateObject private var viewModel = ChatViewModel(initialMessage: "Welcome to the chat! How can i assit you.")

    var body: some View {
        NavigationView { // Optional: Add a Navigation Bar
            VStack {
                // Chat Message List
                ScrollViewReader { proxy in // To scroll to the bottom
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 10) {
                            ForEach(viewModel.messages) { message in
                                ChatMessageView(message: message)
                                    .id(message.id) // Needed for ScrollViewReader
                            }
                        }
                        .padding(.horizontal)
                    }
                    .onChange(of: viewModel.messages.count) { _ in
                         // Auto-scroll to the latest message
                         if let lastMessage = viewModel.messages.last {
                             withAnimation {
                                 proxy.scrollTo(lastMessage.id, anchor: .bottom)
                             }
                         }
                     }
                }


                // Input Area
                HStack {
                    TextField("Ask something...", text: $viewModel.currentInput)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.leading)

                    Button {
                        viewModel.sendMessage()
                    } label: {
                        Image(systemName: "arrow.up.circle.fill")
                            .font(.title)
                    }
                    .padding(.trailing)
                    .disabled(viewModel.currentInput.isEmpty) // Disable if input is empty
                }
                .padding(.bottom)
            }
             //.navigationTitle("General Chat") // Set title if using NavigationView
             //.navigationBarTitleDisplayMode(.inline)
        }
    }
}


