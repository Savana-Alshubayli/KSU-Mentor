// In KSUMentor/SidebarView.swift

import SwiftUI

struct SidebarView: View {
    @Binding var selectedChat: ChatType?
    @Binding var searchText: String
    @Binding var showCalendar: Bool

    // --- ENSURE THIS IS SET TO .blue ---
    let iconColor = Color.blue // Defines the color as blue

    var body: some View {
        VStack(spacing: 0) { // Use VStack to stack header and list

            // --- HEADER ROW ---
            HStack {
                Spacer() // Spacer for centering

                // New Chat Button
                Button { print("New Chat tapped") } label: {
                    Image(systemName: "plus.message.fill")
                        .frame(width: 30, height: 30)
                        .foregroundColor(iconColor) // <-- Uses iconColor (which is blue)
                }

                // Tools Menu
                Menu {
                    Button("Plagiarism Check") { print("Plagiarism Check selected") }
                    Button("AI Detect") { print("AI Detect selected") }
                } label: {
                    Image(systemName: "wrench.and.screwdriver.fill")
                        .frame(width: 30, height: 30)
                        .foregroundColor(iconColor) // <-- Uses iconColor (which is blue)
                }

                // Calendar Button
                Button { showCalendar.toggle() } label: {
                    Image(systemName: "calendar")
                        .frame(width: 30, height: 30)
                        .foregroundColor(iconColor) // <-- Uses iconColor (which is blue)
                }
                .sheet(isPresented: $showCalendar) { CalendarViewWithEvents() }

                // Profile Button
                NavigationLink(destination: ProfileView()) {
                    Image(systemName: "person.crop.circle.fill")
                        .frame(width: 30, height: 30)
                        .foregroundColor(iconColor) // <-- Uses iconColor (which is blue)
                }

                Spacer() // Spacer for centering
            }
            .padding(.vertical)
            .padding(.horizontal)

            // --- LIST CONTENT ---
            List(selection: $selectedChat) {
                // ... (TextField and NavigationLinks) ...
                 TextField("Search Chats", text: $searchText)

                 NavigationLink(tag: ChatType.general, selection: $selectedChat) {
                     GeneralChatView()
                 } label: {
                     Label("General", systemImage: "house.fill")
                 }

                 NavigationLink(tag: ChatType.community, selection: $selectedChat) {
                     CommunityChatView()
                 } label: {
                     Label("Community", systemImage: "person.3.fill")
                 }

                 NavigationLink(tag: ChatType.gradGate, selection: $selectedChat) {
                     GradGateChatView()
                 } label: {
                     Label("GradGate", systemImage: "graduationcap.fill")
                 }

                 NavigationLink(tag: ChatType.mentalHealth, selection: $selectedChat) {
                     MentalHealthView()
                 } label: {
                     Label("Mental Health", systemImage: "heart.fill")
                 }
             }

         } // End VStack
         .navigationTitle("KSUMentor")
     }
}
