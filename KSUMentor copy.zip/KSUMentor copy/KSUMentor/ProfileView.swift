import SwiftUI

struct ProfileView: View {
    var body: some View {
        VStack {
            Text("Profile")
                .font(.title)

            // Add your profile information UI here
            // For example:
            Image(systemName: "person.circle.fill")
                .resizable()
                .frame(width: 100, height: 100)
                .padding()

            Text("Username: JohnDoe123")
            Text("Email: john.doe@example.com")
            // ... other profile details
        }
    }
}
