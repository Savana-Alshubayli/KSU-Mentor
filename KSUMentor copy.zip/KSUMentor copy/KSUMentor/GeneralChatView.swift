import SwiftUI

struct GeneralChatView: View {
    @StateObject private var viewModel = ChatViewModel(initialMessage: "Welcome to the chat! How can i assit you.")

    var body: some View {
        // Removed NavigationView from here if it's already in ContentView or ChatContainerView
        VStack(spacing: 0) { // Use spacing 0 to avoid gaps
            // Chat Message List
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 10) {
                        ForEach(viewModel.messages) { message in
                            ChatMessageView(message: message)
                                .id(message.id)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.top) // Add padding at the top of messages
                }
                .onChange(of: viewModel.messages.count) { _ in
                     if let lastMessage = viewModel.messages.last {
                         withAnimation {
                             proxy.scrollTo(lastMessage.id, anchor: .bottom)
                         }
                     }
                 }
            } // <-- End ScrollViewReader

            // Input Area
            HStack {
                TextField("Ask something...", text: $viewModel.currentInput)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.leading)

                Button {
                    viewModel.sendMessage()
                } label: {
                    Image(systemName: "arrow.up.circle.fill")
                        .font(.title)
                        // Ensure button color contrasts with gray background
                        .foregroundColor(.blue) // Example: Explicitly set color
                }
                .padding(.trailing)
                .disabled(viewModel.currentInput.isEmpty)
            }
            .padding(.vertical) // Add vertical padding to input area
            .background(Color(.systemGray5)) // Optional: Slightly darker gray for input background

        } // <-- End VStack
        .background(Color(.systemGray6).ignoresSafeArea()) // <-- SET GRAY BACKGROUND HERE
        // .navigationTitle("General Chat") // Keep if needed, but might be redundant depending on ContentView structure
        // .navigationBarTitleDisplayMode(.inline)
    }
}


// Simple View for displaying a single chat message bubble
// Simple View for displaying a single chat message bubble
struct ChatMessageView: View {
    let message: ChatMessage

    var body: some View {
        HStack {
            if message.isUser {
                Spacer() // Push user messages to the right
            }
            Text(message.text)
                .padding(10)
                // User message: Blue background, White text
                // Chatbot message: Clear background, White text
                .foregroundColor(.white) // <--- Set text to white for BOTH
                .background(message.isUser ? Color.gray : Color.clear) // <--- User: blue bg, Bot: clear bg
                .cornerRadius(15)
            if !message.isUser {
                Spacer() // Push bot messages to the left
            }
        }
    }
}
