//
//  KSUMentorApp.swift
//  KSUMentor
//
//  Created by Retaj on 25/04/2025.
//

import SwiftUI

@main
struct KSUMentorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
